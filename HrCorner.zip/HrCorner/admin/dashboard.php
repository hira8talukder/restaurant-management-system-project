<?php require('layout/header.php'); ?>
<?php require('layout/left-sidebar-long.php'); ?>
<?php require('layout/topnav.php'); ?>
<?php require('layout/left-sidebar-short.php'); ?>
						
<?php
if (isset($_SESSION['msg'])) {
	echo '<div class="violet-container" style="background:rgb(95, 14, 103)">'.$_SESSION['msg'].'</div>';
	unset($_SESSION['msg']);
}
?>

<div class="violet-container" style="background:rgb(95, 14, 103) margin-top20px">

	<h4>Dashboard</h4>
	
	<div class="violet-container" style="padding: 50px;">
		<div class="violet-container">

			<a class="dash-btn" href="food-list.php"><div class="sec white white-text" style="margin: 15px; padding: 40px;border: 2px solid white; border-radius: 20px; font-size: 20px; background: linear-gradient(to right,rgb(95, 14, 103), rgb(41, 71, 162));">Foods</div></a>
			<a class="dash-btn" href="category-list.php"><div class="sec white white-text" style="margin: 15px; padding: 40px;border: 2px solid white; border-radius: 20px; font-size: 20px; background: linear-gradient(to right,rgb(95, 14, 103), rgb(41, 71, 162));">Categories</div></a>
			<a class="dash-btn" href="order-list.php"><div class="sec white white-text" style="margin: 15px; padding: 40px;border: 2px solid white; border-radius: 20px; font-size: 20px; background: linear-gradient(to right,rgb(95, 14, 103),rgb(41, 71, 162));">Orders</div></a>
			<a class="dash-btn" href="tb.php"><div class="sec white white-text" style="margin: 15px; padding: 40px;border: 2px solid white; border-radius: 20px; font-size: 20px; background: linear-gradient(to right,rgb(95, 14, 103),rgb(41, 71, 162));">Table-Info</div></a>
			<a class="dash-btn" href="employee_management.php" ><div class="sec white white-text" style="margin: 15px; padding: 40px;border: 2px solid white; border-radius: 20px; font-size: 20px; background: linear-gradient(to right,rgb(95, 14, 103),rgb(41, 71, 162));">Employee-Info</div></a>
			<a class="dash-btn" ><div class="sec white white-text" style="margin: 15px; padding: 40px;border: 2px solid white; border-radius: 20px; font-size: 20px; background: linear-gradient(to right,rgb(95, 14, 103),rgb(41, 71, 162));">Review</div></a>
		</div>

	</div>

</div>

<?php require('layout/about-modal.php'); ?>
<?php require('layout/footer.php'); ?>
<?php require('layout/header.php'); ?>
<?php require('layout/left-sidebar-long.php'); ?>
<?php require('layout/topnav.php'); ?>
<?php require('layout/left-sidebar-short.php'); ?>

<?php
require('../backends/connection-pdo.php');

// Fetch all booking data for the manager
$sql = 'SELECT * FROM booking_data';
$query = $pdoconn->prepare($sql);
$query->execute();
$arr_all = $query->fetchAll(PDO::FETCH_ASSOC);
?>

<div class="section white-text" style="background:rgb(95, 14, 103);">

    <div class="section">
        <h3>All Booking Data</h3>
    </div>

    <?php if (isset($_SESSION['msg'])): ?>
        <div class="section center" style="margin: 5px 35px;">
            <div class="row" style="background:rgb(95, 14, 103); color: white;">
                <div class="col s12">
                    <h6><?= htmlspecialchars($_SESSION['msg']); ?></h6>
                </div>
            </div>
        </div>
        <?php unset($_SESSION['msg']); ?>
    <?php endif; ?>
    
    <div class="section center" style="padding: 20px;">
        <table class="centered responsive-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>People</th>
                    <th>Booking Time</th>
                </tr>
            </thead>

            <tbody>
                <?php foreach ($arr_all as $key): ?>
                    <tr>
                        <td><?= htmlspecialchars($key['id']); ?></td>
                        <td><?= htmlspecialchars($key['name']); ?></td>
                        <td><?= htmlspecialchars($key['email']); ?></td>
                        <td><?= htmlspecialchars($key['people']); ?></td>
                        <td><?= htmlspecialchars($key['booking_time']); ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require('layout/about-modal.php'); ?>
<?php require('layout/footer.php'); ?>

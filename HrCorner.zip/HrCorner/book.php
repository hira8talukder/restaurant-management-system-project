<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>HR-CORNAR - Table Booking</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>

    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Pacifico&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Bree+Serif&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <?php require('chunks/navbar.php'); ?>

    <section id="table-booking" class="container">
        <h4 class="center-align">Book a Table</h4>
        <form id="booking-form" method="POST" action="">
            <div class="input-field">
                <input type="text" id="name" name="name" required>
                <label for="name">Your Name</label>
            </div>
            <div class="input-field">
                <input type="email" id="email" name="email" required>
                <label for="email">Your Email</label>
            </div>
            <div class="input-field">
                <input type="number" id="people" name="people" min="1" required>
                <label for="people">Number of People</label>
            </div>
            <div class="input-field">
                <input type="datetime-local" id="booking_time" name="booking_time" required>
                <label for="booking_time"></label>
            </div>
            <button type="submit" name="book" class="btn waves-effect waves-light">Book Now</button>
        </form>
    </section>

    <?php
    if (isset($_POST['book'])) {
        // Database connection
        $conn = new mysqli("localhost", "root", "", "mishtidb");

        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        $user_id = (int) $_SESSION['user_id'];
        $name = $conn->real_escape_string($_POST['name']);
        $email = $conn->real_escape_string($_POST['email']);
        $people = (int) $_POST['people'];
        $booking_time = $conn->real_escape_string($_POST['booking_time']);

        // Verify if user_id exists in users table
        $result = $conn->query("SELECT id FROM users WHERE id = $user_id");
        if ($result->num_rows === 0) {
            echo "<p class='red-text center-align'>Error: User ID does not exist in the users table.</p>";
            exit;
        }

        // Insert booking data
        $sql = "INSERT INTO booking_data (user_id, name, email, people, booking_time) VALUES ($user_id, '$name', '$email', $people, '$booking_time')";

        if ($conn->query($sql) === TRUE) {
            $id = $conn->insert_id;
            echo "<p class='green-text center-align'>Booking Successful!</p>";
            echo "<p class='green-text center-align'>Your table no is : " . $id . "</p>";
        } else {
            echo "<p class='red-text center-align'>Error: " . $conn->error . "</p>";
        }

        $conn->close();
    }
    ?>

    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
</body>
</html>

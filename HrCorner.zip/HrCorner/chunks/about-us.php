<section class="fabout">
		<div class="section white center">
		      <div class="row container">
		        <h2 class="header">ABOUT US</h2>
		        <p class="grey-text text-darken-3 lighten-3">
				Are you in a hurry or tired of waiting in the queue? Do not need to worry; we have this for you! Reserveit is the first online
				restaurant booking service provider based in Bangladesh. This is a simple application to make it easier to choose your restaurants.
				The application makes it straight forward to search for restaurants near or far from your location, check all food menus, preview
				food and restaurant photos, get exact locations, get instant notification of your reservation, choose your restaurants, and share 
				reviews. We are here to assist you in finding the best restaurants and hottest promotions in Bangladesh. With our passion for hospitality, 
				we take pride in bringing together people and the restaurants they love in the moments that matter.</p>
		      </div>
	</section>
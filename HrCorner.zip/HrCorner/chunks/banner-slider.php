<section class="fslider">
		<div class="slider">
			<ul class="slides">
		    <li>
		    	<img src="images/banner8.jpg">
		    	<div class = "caption center-align bright-green-text" style="color:rgb(255, 246, 252); text-shadow: 2px 2px 2px black;"> 
		        <h3 style="font-size: 3rem !important; font-weight: bold !important; font-family: 'Bree Serif', serif ;">KHAWON - The Quality Food!</h3>  
		        <h5 class = "light" style = "color:rgb(255, 236, 249);"><strong>We deliver Quality. Try us and then buy us!</strong></h5>  
		      </div>  
		    </li>

		    <li>
		    	<img src="images/banner9.jpg">
		    	<div class = "caption center-align bright-green-text" style="color:rgb(255, 246, 252); text-shadow: 2px 2px 2px black;"> 
		        <h3 style="font-size: 3rem !important; font-weight: bold !important; font-family: 'Bree Serif', serif ;">Quality Food Always</h3>  
		        <h5 class="light" style = "color:rgb(255, 236, 249);"><strong>We deliver Quality And We're doing this for years!</strong></h5>  
		      </div>  
		    </li>

			<li>
		    	<img src="images/banner10.jpg">
		    	<div class = "caption center-align bright-green-text" style="color:rgb(255, 246, 252); text-shadow: 2px 2px 2px black;"> 
		        <h3 style="font-size: 3rem !important; font-weight: bold !important; font-family: 'Bree Serif', serif ;">Quality Food Always</h3>  
		        <h5 class="light" style = "color:rgb(255, 236, 249);"><strong>We deliver Quality And We're doing this for years!</strong></h5>  
		      </div>  
		    </li>

			<li>
		    	<img src="images/banner12.jpg">
		    	<div class = "caption center-align bright-green-text" style="color:rgb(255, 246, 252); text-shadow: 2px 2px 2px black;"> 
		        <h3 style="font-size: 3rem !important; font-weight: bold !important; font-family: 'Bree Serif', serif ;">Quality Food Always</h3>  
		        <h5 class="light" style = "color:rgb(255, 236, 249);"><strong>We deliver Quality And We're doing this for years!</strong></h5>  
		      </div>  
		    </li>

			<li>
		    	<img src="images/banner13.jpg">
		    	<div class = "caption center-align bright-green-text" style="color:rgb(255, 246, 252); text-shadow: 2px 2px 2px black;"> 
		        <h3 style="font-size: 3rem !important; font-weight: bold !important; font-family: 'Bree Serif', serif ;">Quality Food Always</h3>  
		        <h5 class="light" style = "color:rgb(255, 236, 249);"><strong>We deliver Quality And We're doing this for years!</strong></h5>  
		      </div>  
		    </li>

		    </ul>


		   
	  </div>
	</section>
<section class="fdes">
		<div class="section white center">
			<h2 class="header" style="padding:20px; padding-bottom: 30px;">Restaurant Powered By KHAWON team</h2>
		      <div class="row container center">
		        <div class="col center l8 s12">
		        	<p>Khawon is a cozy Bangladeshi restaurant that offers a delicious 
						variety of traditional dishes, blending rich spices and authentic flavors.
						 Known for its warm hospitality and vibrant ambiance, Khawon serves 
						 favorites like biryani, kebabs, and flavorful curries,
						 making it the perfect spot to enjoy the true taste of Bangladesh.</p>
		        </div>
		        <div class="col center l4 s12">
		        	<img height="300" width="auto" style="object-fit: contain;" src="images/chef.jpg" alt="">
		        </div>
		        
		      </div>
	</section>
<!-- <section class="freviews">

		<div class="section white center">
			<h3 class="header">What Our Customers Say</h3>
			<div class="carousel myreviews" style="margin-bottom: 35px;">
			    <a class="carousel-item" href="#one!">
			    	<div class="row">
					    <div class="col s12">
					      <div class="card-panel teal" style="background:rgb(157, 126, 168) !important;">
					        <span class="white-text">"The food of this resturant is just like heaven for me!
								 Its so delicious and tasty that I can't help going there every weekend!"<br>-<br> <strong>Tamim</strong>
					        </span>
					      </div>
					    </div>
					  </div>
			    </a>
			    <a class="carousel-item" href="#two!">
			    	<div class="row">
					    <div class="col s12">
					      <div class="card-panel teal" style="background: rgb(157, 126, 168) !important;">
					        <span class="white-text">"The food of this resturant is just like heaven for me!
								 Its so delicious and tasty that
								 I can't help going there every weekend!"<br>-<br> <strong>Rohan Roy</strong>
					        </span>
					      </div>
					    </div>
					  </div>
			    </a>
			    <a class="carousel-item" href="#three!">
			    	<div class="row">
					    <div class="col s12">
					      <div class="card-panel teal" style="background: rgb(157, 126, 168) !important;">
					        <span class="white-text">"The food of this resturant is just like heaven for me!
								 Its so delicious and tasty that I can't help going there every weekend!"<br>-<br> <strong>Jeson</strong>
					        </span>
					      </div>
					    </div>
					  </div>
			    </a>
			    <a class="carousel-item" href="#four!">
			    	<div class="row">
					    <div class="col s12">
					      <div class="card-panel teal" style="background: rgb(157, 126, 168) !important;">
					        <span class="white-text">"The food of this resturant is just like heaven for me!
								 Its so delicious and tasty that I can't help going there every weekend!"<br>-<br> <strong>Farhan Ahmed</strong>
					        </span>
					      </div>
					    </div>
					  </div>
			    </a>
			    <a class="carousel-item" href="#five!">
			    	<div class="row">
					    <div class="col s12">
					      <div class="card-panel teal" style="background: rgb(157, 126, 168)!important;">
					        <span class="white-text">"The food of this resturant is just like heaven for me!
								 Its so delicious and tasty that I can't help going there every weekend!"<br>-<br> <strong>Riya Dutta</strong>
					        </span>
					      </div>
					    </div>
					  </div>
			    </a>
			    <a class="carousel-item" href="#six!">
			    	<div class="row">
					    <div class="col s12">
					      <div class="card-panel teal" style="background: rgb(157, 126, 168) !important;">
					        <span class="white-text">"The food of this resturant is just like heaven for me! 
								Its so delicious and tasty that I can't help going there every weekend!"<br>-<br> <strong>Jasmine Sinha</strong>
					        </span>
					      </div>
					    </div>
					  </div>
			    </a>
			    <a class="carousel-item" href="#seven!">
			    	<div class="row">
					    <div class="col s12">
					      <div class="card-panel teal" style="background: rgb(157, 126, 168) !important;">
					        <span class="white-text">"The food of this resturant is just like heaven for me!
								 Its so delicious and tasty that I can't help going there every weekend!"<br>-<br> <strong>Akash Roy</strong>
					        </span>
					      </div>
					    </div>
					  </div>
			    </a>
			  </div>
		</div>
	</section> -->
<!-- <body>
<section class="freviews">
    <div class="section white center">
        <h3 class="header">What Our Customers Say</h3>
        <div class="carousel myreviews" style="margin-bottom: 35px;">
            <a class="carousel-item" href="#one!">
                <div class="row">
                    <div class="col s12">
                        <div class="card-panel teal" style="background: rgb(157, 126, 168) !important;">
                            <span class="white-text">
                                "The food of this restaurant is just like heaven for me!
                                It's so delicious and tasty that I can't help going there every weekend!"<br>-<br>
                                <strong>Tamim</strong>
                            </span>
                        </div>
                    </div>
                </div>
            </a>
            <a class="carousel-item" href="#two!">
                <div class="row">
                    <div class="col s12">
                        <div class="card-panel teal" style="background: rgb(157, 126, 168) !important;">
                            <span class="white-text">
                                "The food of this restaurant is just like heaven for me!
                                It's so delicious and tasty that I can't help going there every weekend!"<br>-<br>
                                <strong>Rohan Roy</strong>
                            </span>
                        </div>
                    </div>
                </div>
            </a>
            <a class="carousel-item" href="#three!">
                <div class="row">
                    <div class="col s12">
                        <div class="card-panel teal" style="background: rgb(157, 126, 168) !important;">
                            <span class="white-text">
                                "The food of this restaurant is just like heaven for me!
                                It's so delicious and tasty that I can't help going there every weekend!"<br>-<br>
                                <strong>Jeson</strong>
                            </span>
                        </div>
                    </div>
                </div>
            </a>
            Add more items as needed --> -->
        <!-- </div>
    </div>
</section>

<script>
	document.addEventListener('DOMContentLoaded', function () {
    const elems = document.querySelectorAll('.carousel');
    const instances = M.Carousel.init(elems, {
        fullWidth: true, // Ensures the carousel spans the full width.
        indicators: true, // Adds dots for navigation.
    });

    // Auto-slide logic
    setInterval(() => {
        const instance = M.Carousel.getInstance(document.querySelector('.myreviews'));
        instance.next(); // Move to the next item.
    }, 3000); // Change every 3 seconds.
});

</script> -->
 
<!-- </body> -->
	
 

 <head>
    <style>
        /* Adjust the height of the carousel items */
        * {
    box-sizing: border-box;
}

.carousel {
    width: 100%;
    max-width: 100%;
    overflow: hidden;
    margin: 0 auto;
}

.carousel .carousel-item {
    width: 100%;
    max-width: 100%;
    margin: 0 auto;
}

.carousel .carousel-item img {
    max-width: 100%;
    height: auto;
    display: block;
    margin: 0 auto;
}

html, body {
    overflow-x: hidden;
    width: 100%;
}

    </style>
</head>
<body>
    <section class="freviews">
        <div class="section white center">
            <h3 class="header">What Our Customers Say</h3>
            <div class="carousel myreviews" style="margin-bottom: 35px;">
                <a class="carousel-item" href="#one!">
                    <div class="row">
                        <div class="col s12">
                            <div class="card-panel teal" style="background: rgb(100, 5, 121) !important;">
                                <span class="white-text">
                                    "The food of this restaurant is just like heaven for me!
                                    It's so delicious and tasty that I can't help going there every weekend!"<br>-<br>
                                    <strong>Tamim</strong>
                                </span>
                            </div>
                        </div>
                    </div>
                </a>
                <a class="carousel-item" href="#two!">
                    <div class="row">
                        <div class="col s12">
                            <div class="card-panel teal" style="background: rgb(100, 5, 121) !important;">
                                <span class="white-text">
                                    "The food of this restaurant is just like heaven for me!
                                    It's so delicious and tasty that I can't help going there every weekend!"<br>-<br>
                                    <strong>Rohan Roy</strong>
                                </span>
                            </div>
                        </div>
                    </div>
                </a>
                <a class="carousel-item" href="#three!">
                    <div class="row">
                        <div class="col s12">
                            <div class="card-panel teal" style="background: rgb(100, 5, 121) !important;">
                                <span class="white-text">
                                    "The food of this restaurant is just like heaven for me!
                                    It's so delicious and tasty that I can't help going there every weekend!"<br>-<br>
                                    <strong>Jeson</strong>
                                </span>
                            </div>
                        </div>
                    </div>
                </a>
            </div>
        </div>
    </section>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const elems = document.querySelectorAll('.carousel');
            const instances = M.Carousel.init(elems, {
                fullWidth: true, // Ensures the carousel spans the full width.
                // indicators: true, // Adds dots for navigation.
            });

            // Auto-slide logic
            setInterval(() => {
                const instance = M.Carousel.getInstance(document.querySelector('.myreviews'));
                instance.next(); // Move to the next item.
            }, 3000); // Change every 3 seconds.
        });
    </script>
</body>

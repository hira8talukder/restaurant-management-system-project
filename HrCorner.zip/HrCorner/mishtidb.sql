-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 31, 2025 at 03:06 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mishtidb`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `name` varchar(250) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `name`, `email`, `password`) VALUES
(1, 'Admin', 'admin@gmail.com', '12345'),
(8, 'Hira', 'hira@gmail.com', 'uiu');

-- --------------------------------------------------------

--
-- Table structure for table `booking_data`
--

CREATE TABLE `booking_data` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `people` int(11) NOT NULL,
  `booking_time` datetime NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `booking_data`
--

INSERT INTO `booking_data` (`id`, `name`, `email`, `people`, `booking_time`, `user_id`) VALUES
(1, 'hira', 'hira@gmail.com', 5, '2025-01-29 14:00:00', 4),
(6, 'sunni', 'sunni@gmail.com', 8, '2025-01-24 11:24:00', 5),
(7, 'hira', 'joy@gmail.com', 4, '2025-01-26 09:35:00', 8),
(8, 'joy', 'joy@gmail.com', 2, '2025-01-31 11:00:00', 8),
(9, 'joy', 'hira@gmail.com', 4, '2025-01-26 20:00:00', 8),
(10, 'sadadad', 'admin@gmail.com', 23, '2025-12-31 00:59:00', 8),
(11, 'abc', 'zx@gmail.com', 4, '2025-01-29 13:45:00', 4),
(12, 'hr', 'hr@gmail.com', 4, '2025-02-07 10:00:00', 9);

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `name` varchar(250) NOT NULL,
  `short_desc` varchar(250) NOT NULL,
  `long_desc` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `short_desc`, `long_desc`) VALUES
(8, 'Chinese', 'Chinese cuisine is an important part of Chinese culture, which includes cuisine originating from the diverse regions of China.', 'A number of different styles contribute to Chinese cuisine but perhaps the best known and most influential are Cantonese cuisine, Shandong cuisine, Jiangsu cuisine (specifically Huaiyang cuisine) and Sichuan cuisine.'),
(9, 'South Indian', 'South Indian cuisine includes the cuisines of the five southern states of India Andhra Pradesh, Karnataka, Kerala, Tamil Nadu and Telangana.', 'The cuisines of Andhra Pradesh are the spiciest in all of India. Generous use of chili and tamarind make the dishes tangy and hot. The majority of dishes are vegetable or lentil-based.'),
(10, 'Snacks', ' A snack is a small portion of food eaten between meals.', 'A snack is a small portion of food eaten between meals. This may be a snack food, such as potato chips or baby carrots, but can also simply be a small amount of any food.'),
(11, 'Himalayan Food', 'Nepalese cuisine comprises a variety of cuisines based upon ethnicity, soil and climate relating to Nepal cultural diversity and geography.', 'Much of the cuisine is variation on Asian themes. Other foods have hybrid Tibetan, Indian and Thai origins. They were originally filled with buffalo meat but now also with goat or chicken, as well as vegetarian preparations. Special foods such as sel roti, finni roti and patre are eaten during festivals such as Tihar.'),
(12, 'Bangladeshi food', 'good', 'good food . love it'),
(13, 'Franch', 'A British cookie named after the historic Bourbonnais region in France', 'The Bourbon biscuit is a popular British cookie named after the historic Bourbonnais region in France. It features a chocolate-flavored filling sandwiched between two rectangular chocolate biscuits.');

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `employee_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `contact` varchar(15) NOT NULL,
  `address` text NOT NULL,
  `role` varchar(100) NOT NULL,
  `join_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`employee_id`, `name`, `contact`, `address`, `role`, `join_date`) VALUES
(1, 'Hira', '1234567890', '123 Main St, Dhaka', 'Manager', '2025-01-01'),
(4, 'Mahmud', '1234567840', '123 Main St, Dhaka', 'Waiter', '2025-01-01'),
(5, 'Fardin', '123454890', ' Dhaka', 'Waiter', '2025-01-01');

-- --------------------------------------------------------

--
-- Table structure for table `food`
--

CREATE TABLE `food` (
  `id` int(11) NOT NULL,
  `cat_id` int(10) NOT NULL,
  `fname` varchar(50) NOT NULL,
  `description` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `food`
--

INSERT INTO `food` (`id`, `cat_id`, `fname`, `description`) VALUES
(15, 12, 'Kacchi', 'TK-350'),
(17, 8, 'Hakka Noodlse', 'Tk-240'),
(18, 10, 'ice cream', '150');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `order_id` varchar(20) NOT NULL,
  `user_id` int(11) NOT NULL,
  `food_id` int(11) NOT NULL,
  `user_name` varchar(100) NOT NULL,
  `timestamp` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `order_id`, `user_id`, `food_id`, `user_name`, `timestamp`) VALUES
(3, 'RSTGF384345', 3, 1, 'Samprit', '04:09:2019 12:02:06am'),
(4, 'RSTGF790352', 4, 12, 'Hira', '09:01:2025 08:34:42pm'),
(5, 'RSTGF739056', 4, 10, 'Hira', '09:01:2025 08:35:09pm'),
(6, 'RSTGF608511', 5, 13, 'sunni', '13:01:2025 09:44:07pm'),
(7, 'RSTGF618746', 5, 10, 'sunni', '13:01:2025 09:44:34pm'),
(8, 'RSTGF708857', 6, 9, 'Sifat', '19:01:2025 09:14:03am'),
(9, 'RSTGF583756', 7, 15, 'nurul', '20:01:2025 11:23:26pm'),
(10, 'RSTGF870496', 4, 9, 'Hira', '21:01:2025 12:15:30pm'),
(11, 'RSTGF471353', 4, 8, 'Hira', '22:01:2025 02:10:32am'),
(12, 'RSTGF293789', 8, 9, 'hrs', '25:01:2025 08:00:43pm'),
(13, 'RSTGF663259', 8, 16, 'hrs', '25:01:2025 08:01:33pm'),
(14, 'RSTGF685978', 8, 9, 'hrs', '26:01:2025 02:24:42pm'),
(15, 'RSTGF921219', 8, 15, 'hrs', '27:01:2025 08:49:45am'),
(16, 'RSTGF541064', 8, 16, 'hrs', '27:01:2025 10:22:04am'),
(17, 'RSTGF518386', 4, 16, 'Hira', '27:01:2025 12:05:29pm'),
(18, 'RSTGF732866', 4, 16, 'Hira', '27:01:2025 12:47:17pm'),
(19, 'RSTGF324093', 4, 17, 'Hira', '27:01:2025 12:47:25pm'),
(20, 'RSTGF370920', 9, 16, 'hr', '31:01:2025 06:56:22pm');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `timestamp` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `timestamp`) VALUES
(3, 'Mishti Chakraborty', 'mishti@gmail.com', '12345', '06:08:2019 01:40:08am'),
(4, 'Hira Talukder', 'hira@gmail.com', 'uiu', '09:01:2025 08:32:49pm'),
(5, 'sunni', 'sunni@gmail.com', 'uiu', '13:01:2025 09:42:54pm'),
(6, 'Sifat', 'sifat@gmail.com', 'uiu', '19:01:2025 09:12:50am'),
(7, 'nurul', 'nurul@gmail.com', 'uiu', '20:01:2025 11:22:30pm'),
(8, 'hrs', 'hrt@gmail.com', 'uiu', '25:01:2025 07:29:45pm'),
(9, 'hr', 'hr@gmail.com', 'uiu', '31:01:2025 06:55:36pm');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `booking_data`
--
ALTER TABLE `booking_data`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_fkey` (`user_id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`employee_id`);

--
-- Indexes for table `food`
--
ALTER TABLE `food`
  ADD PRIMARY KEY (`id`),
  ADD KEY `cat_id` (`cat_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `booking_data`
--
ALTER TABLE `booking_data`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `food`
--
ALTER TABLE `food`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `booking_data`
--
ALTER TABLE `booking_data`
  ADD CONSTRAINT `id_fkey` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `food`
--
ALTER TABLE `food`
  ADD CONSTRAINT `cat_id` FOREIGN KEY (`cat_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
